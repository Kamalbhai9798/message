const contacts = [
  {
    name: "Aditi Sharma",
    status: "Online",
    pic: "https://i.pravatar.cc/150?img=1",
    messages: []
  },
  {
    name: "Rahul Verma",
    status: "Away",
    pic: "https://i.pravatar.cc/150?img=3",
    messages: []
  },
  {
    name: "Sneha Reddy",
    status: "Offline",
    pic: "https://i.pravatar.cc/150?img=5",
    messages: []
  }
];

let currentChat = null;

const contactList = document.getElementById("contactList");
contacts.forEach((contact, index) => {
  const li = document.createElement("li");
  li.className = "contact";
  li.innerHTML = `
    <img src="${contact.pic}" alt="DP">
    <div class="info">
      <div class="name">${contact.name}</div>
      <div class="status">${contact.status}</div>
    </div>
  `;
  li.onclick = () => loadChat(index);
  contactList.appendChild(li);
});

function loadChat(index) {
  currentChat = contacts[index];

  document.getElementById("chatUserPic").src = currentChat.pic;
  document.getElementById("chatUserName").textContent = currentChat.name;
  document.getElementById("chatUserStatus").textContent = currentChat.status;

  renderMessages();
}

function renderMessages() {
  const chatBox = document.getElementById("chatBox");
  chatBox.innerHTML = "";

  if (!currentChat || currentChat.messages.length === 0) {
    chatBox.innerHTML = '<p class="no-chat">Start a conversation</p>';
    return;
  }

  currentChat.messages.forEach(msg => {
    const msgDiv = document.createElement("div");
    msgDiv.className = `message ${msg.type}`;
    msgDiv.textContent = msg.text;
    chatBox.appendChild(msgDiv);
  });

  chatBox.scrollTop = chatBox.scrollHeight;
}

document.getElementById("chatForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const input = document.getElementById("messageInput");
  const text = input.value.trim();
  if (!text || !currentChat) return;

  currentChat.messages.push({ text, type: "sent" });

  setTimeout(() => {
    currentChat.messages.push({ text: "Thanks for your message!", type: "received" });
    renderMessages();
  }, 800);

  input.value = "";
  renderMessages();
});